
		case 'qq_login':		include _include(APP_PATH.'plugin/xn_qq_login/route/qq_login.php'); 	break;