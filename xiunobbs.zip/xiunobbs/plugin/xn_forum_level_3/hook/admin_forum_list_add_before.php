<?php exit;

$arr['fup'] = array_value($fuparr, $k);

?>